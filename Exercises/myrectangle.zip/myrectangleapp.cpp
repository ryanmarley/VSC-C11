#include <iostream>
using namespace std;
#include "myrectangle.h"

int main() {
    MyRectangle rec(3.0, 5.0);
    rec.print();

    return 0;
}